oc start-build -n $1 bc/sso-bot --from-file=. --follow
