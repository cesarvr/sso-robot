#!/bin/bash

oc delete ClusterRole sso-god
oc delete ClusterRoleBinding sso-robot-god

