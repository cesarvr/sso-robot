set OKD_SERVER=https://console.rhos.agriculture.gov.ie
set DEBUG=true
